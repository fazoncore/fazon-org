# FAZON TR-1 / TR-2 Site Deployment

This repository contains the deployable version of the FAZON website, supporting TR-1 (public) and TR-2 (NFT-gated) layers.

## Structure
- `index.html`: Core entry page
- `README.md`: Overview

## Instructions
1. Upload contents to GitHub repository
2. Enable GitHub Pages (main branch / root)
3. Done — your site is live
